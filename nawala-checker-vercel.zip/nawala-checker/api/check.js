export default async function handler(req, res) {
  const domain = String(req.query.domain || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0];

  if (!domain) {
    return res.status(400).json({
      success: false,
      status: "ERROR",
      message: "Domain kosong"
    });
  }

  try {
    const url = "https://apiv1.aethercloud.web.id/check?domain=" + encodeURIComponent(domain);
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json"
      }
    });

    const text = await response.text();

    if (!response.ok) {
      return res.status(200).json({
        success: false,
        status: "ERROR",
        message: "API HTTP " + response.status
      });
    }

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return res.status(200).json({
        success: false,
        status: "ERROR",
        message: "Response bukan JSON"
      });
    }

    let status = "UNKNOWN";

    if (Array.isArray(data.results)) {
      const found = data.results.find(x =>
        String(x.domain || "").toLowerCase() === domain
      );
      if (found) status = String(found.status || "UNKNOWN").toUpperCase();
    } else if (data.status) {
      status = String(data.status).toUpperCase();
    } else if (typeof data.blocked === "boolean") {
      status = data.blocked ? "BLOCKED" : "SAFE";
    }

    return res.status(200).json({ success: true, domain, status });
  } catch (error) {
    return res.status(200).json({
      success: false,
      domain,
      status: "ERROR",
      message: error.message
    });
  }
}
